/**
 * AlloIA Subscription Management JavaScript
 * 
 * @package AlloIA_WooCommerce
 */

(function($) {
    'use strict';
    
    /**
     * AlloIA Subscription Manager
     */
    var AlloIASubscription = {
        
        /**
         * Initialize the subscription manager
         */
        init: function() {
            this.bindEvents();
            this.initializeTooltips();
            this.setupAutoRefresh();
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Subscribe button clicks
            $(document).on('click', '.subscribe-button', this.handleSubscribeClick);
            
            // Modal close events
            $(document).on('click', '.close', this.closeModal);
            $(document).on('click', '.modal', this.handleModalOutsideClick);
            
            // Form submission
            $(document).on('submit', '#subscription-form', this.handleFormSubmission);
            
            // Plan selection
            $(document).on('change', '.plan-selector', this.handlePlanChange);
            
            // Cancel subscription confirmation
            $(document).on('click', '.cancel-subscription', this.handleCancelSubscription);
        },
        
        /**
         * Handle subscribe button click
         */
        handleSubscribeClick: function(e) {
            e.preventDefault();
            
            var planId = $(this).data('plan');
            var planName = $(this).data('plan-name');
            
            // Update modal with plan information
            $('#selected_plan_id').val(planId);
            $('#selected_plan_name').text(planName);
            
            // Show modal
            $('#subscription-modal').show();
            
            // Focus on email field
            $('#customer_email').focus();
        },
        
        /**
         * Close modal
         */
        closeModal: function() {
            $('#subscription-modal').hide();
            $('#subscription-form')[0].reset();
        },
        
        /**
         * Handle clicks outside modal
         */
        handleModalOutsideClick: function(e) {
            if ($(e.target).is('#subscription-modal')) {
                AlloIASubscription.closeModal();
            }
        },
        
        /**
         * Handle form submission
         */
        handleFormSubmission: function(e) {
            var email = $('#customer_email').val();
            var companyName = $('#company_name').val();
            
            // Basic validation
            if (!email) {
                e.preventDefault();
                alert('Please enter your email address.');
                $('#customer_email').focus();
                return false;
            }
            
            if (!AlloIASubscription.isValidEmail(email)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
                $('#customer_email').focus();
                return false;
            }
            
            // Show loading state
            var submitButton = $(this).find('input[type="submit"]');
            var originalText = submitButton.val();
            
            submitButton.val('Processing...').prop('disabled', true);
            
            // Re-enable button after a delay (in case of errors)
            setTimeout(function() {
                submitButton.val(originalText).prop('disabled', false);
            }, 5000);
        },
        
        /**
         * Handle plan change
         */
        handlePlanChange: function() {
            var selectedPlan = $(this).val();
            var planDetails = AlloIASubscription.getPlanDetails(selectedPlan);
            
            if (planDetails) {
                AlloIASubscription.updatePlanDisplay(planDetails);
            }
        },
        
        /**
         * Handle cancel subscription
         */
        handleCancelSubscription: function(e) {
            if (!confirm('Are you sure you want to cancel your subscription? This action cannot be undone.')) {
                e.preventDefault();
                return false;
            }
            
            // Show loading state
            var button = $(this);
            var originalText = button.val();
            
            button.val('Cancelling...').prop('disabled', true);
            
            // Re-enable button after a delay
            setTimeout(function() {
                button.val(originalText).prop('disabled', false);
            }, 5000);
        },
        
        /**
         * Get plan details
         */
        getPlanDetails: function(planId) {
            var plans = {
                'price_dashboard_plan': {
                    name: 'Dashboard Plan',
                    price: '$29',
                    features: ['Analytics Dashboard', 'AI Bot Tracking', 'Basic Performance Metrics', 'GEO Analytics']
                },
                'price_graph_plan': {
                    name: 'Graph Plan',
                    price: '$79',
                    features: ['Everything in Dashboard Plan', 'Knowledge Graph Export', 'Product Optimization', 'Competitor Analysis', 'Advanced Analytics']
                },
                'price_enterprise_plan': {
                    name: 'Enterprise Plan',
                    price: '$199',
                    features: ['Everything in Graph Plan', 'Custom AI Models', 'Priority Support', 'White-label Solutions', 'API Access']
                }
            };
            
            return plans[planId] || null;
        },
        
        /**
         * Update plan display
         */
        updatePlanDisplay: function(planDetails) {
            $('#plan-name').text(planDetails.name);
            $('#plan-price').text(planDetails.price);
            
            var featuresList = $('#plan-features');
            featuresList.empty();
            
            planDetails.features.forEach(function(feature) {
                featuresList.append('<li>' + feature + '</li>');
            });
        },
        
        /**
         * Initialize tooltips
         */
        initializeTooltips: function() {
            // Add tooltips to plan features
            $('.plan-features li').each(function() {
                var feature = $(this).text();
                $(this).attr('title', feature);
            });
        },
        
        /**
         * Setup auto-refresh for subscription status
         */
        setupAutoRefresh: function() {
            // Refresh subscription status every 5 minutes
            setInterval(function() {
                AlloIASubscription.refreshSubscriptionStatus();
            }, 300000);
        },
        
        /**
         * Refresh subscription status
         */
        refreshSubscriptionStatus: function() {
            // This would typically make an AJAX call to refresh the status
            // For now, just log that it would happen
            // Subscription status refresh - handled by page reload
        },
        
        /**
         * Validate email format
         */
        isValidEmail: function(email) {
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },
        
        /**
         * Show notification
         */
        showNotification: function(message, type) {
            type = type || 'info';
            
            var notification = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
            
            $('.wrap h1').after(notification);
            
            // Auto-dismiss after 5 seconds
            setTimeout(function() {
                notification.fadeOut();
            }, 5000);
        },
        
        /**
         * Format currency
         */
        formatCurrency: function(amount, currency) {
            currency = currency || 'USD';
            
            if (currency === 'USD') {
                return '$' + parseFloat(amount).toFixed(2);
            }
            
            return parseFloat(amount).toFixed(2) + ' ' + currency;
        },
        
        /**
         * Format date
         */
        formatDate: function(dateString) {
            var date = new Date(dateString);
            return date.toLocaleDateString();
        }
    };
    
    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        AlloIASubscription.init();
    });
    
    /**
     * Make available globally
     */
    window.AlloIASubscription = AlloIASubscription;
    
})(jQuery);
