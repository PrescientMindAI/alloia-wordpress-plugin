<?php
/**
 * Pro Features Template
 * 
 * @package AlloIA_WooCommerce
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get WooCommerce product count for plan calculation
$product_count = 0;
if (class_exists('WooCommerce')) {
    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids'
    );
    $products = get_posts($args);
    $product_count = count($products);
}

// Calculate recommended plan
$recommended_plan = '';
$plan_price = '';
$plan_description = '';
if ($product_count <= 1000) {
    $recommended_plan = 'Knowledge Graph 1K';
    $plan_price = '$250 CAD/month';
    $plan_description = 'Perfect for stores with up to 1,000 products';
} elseif ($product_count <= 5000) {
    $recommended_plan = 'Knowledge Graph 5K';
    $plan_price = '$400 CAD/month';
    $plan_description = 'Ideal for stores with up to 5,000 products';
} elseif ($product_count <= 10000) {
    $recommended_plan = 'Knowledge Graph 10K';
    $plan_price = '$700 CAD/month';
    $plan_description = 'Best for stores with up to 10,000 products';
} else {
    $recommended_plan = 'Knowledge Graph Enterprise';
    $plan_price = '$700 CAD/month + $140/month per 10K additional';
    $plan_description = 'Custom pricing for large catalogs';
}
?>

<div class="alloia-pro-section">
    <?php if (!class_exists('WooCommerce')): ?>
        <div class="notice notice-warning" style="margin-bottom: 20px;">
            <p><strong>⚠️ WooCommerce Required:</strong> The Pro Features require WooCommerce to manage your products and provide AI optimization capabilities. 
            <a href="<?php echo esc_url(admin_url('plugin-install.php?s=woocommerce&tab=search&type=term')); ?>" class="button button-primary" style="margin-left: 10px;">Install WooCommerce</a></p>
        </div>
    <?php endif; ?>
    
    <div class="alloia-card alloia-pro-header">
        <h2>Advanced e-commerce AI capabilities for serious merchants</h2>
        <p>Get detailed analytics, AI ready graph and optimisation + Always priority support.</p>
    </div>

    <?php if (!$data['is_pro']): ?>
        <!-- Promo boxes when no subscription -->
        <div class="alloia-card alloia-analytics-grid">
            <div class="alloia-analytics-card">
                <div style="text-align:center;margin-bottom:15px;">
                    <div style="width:60px;height:60px;background:#e6f5ea;border-radius:50%;margin:0 auto 10px;display:flex;align-items:center;justify-content:center;">
                        <span class="dashicons dashicons-admin-site-alt3" style="font-size:24px;color:#4caf50;"></span>
                    </div>
                </div>
                <h4>AI Alternative Site</h4>
                <p style="color:#007cba;font-weight:600;margin:10px 0;">Optimized AI Knowledge Graph Rendering</p>
                <div style="font-size:24px;font-weight:bold;color:#4caf50;margin:15px 0;">Starting from $250/month</div>
                <p style="margin:15px 0;color:#646970;">Zero impact on site SEO, dynamically adapts content for each AI and LLM</p>
                <ul style="text-align:left;margin:15px 0;color:#646970;font-size:14px;">
                    <li>• ≤1000 SKU: $250/month</li>
                    <li>• ≤5000 SKU: $400/month</li>
                    <li>• ≤10000 SKU: $700/month + $140/month per 10K additional</li>
                    <li>• 10K free queries/month, premium levels available</li>
                </ul>
                <a href="https://alloia.ai/dashboard/billing?plan=graph_auto&entities=<?php echo esc_attr($product_count); ?>&domain=<?php echo esc_attr(wp_parse_url(home_url(), PHP_URL_HOST)); ?>&redirect=wp-admin/plugins.php" target="_blank" class="button button-primary">
                    <?php esc_html_e('Subscribe Now', 'geo-ia-optimisation-alloia'); ?>
                </a>
            </div>
        </div>

        <!-- Partner Code Section -->
        <div class="alloia-card alloia-setting-group" style="margin-top:20px;">
            <div class="alloia-setting-info">
                <strong><?php esc_html_e('Partner Code (Optional)', 'geo-ia-optimisation-alloia'); ?></strong>
                <p><?php esc_html_e('Enter here the code provided by your agency or AlloIA partner, it will link this website to them and make support from them more easy.', 'geo-ia-optimisation-alloia'); ?></p>
                <div style="display:flex;gap:10px;align-items:center;margin-top:10px;">
                    <input type="text" id="partner_code" placeholder="<?php esc_attr_e('Enter partner code...', 'geo-ia-optimisation-alloia'); ?>" class="regular-text" style="min-width:300px;" />
                    <button type="button" id="apply_partner_code" class="button button-secondary">
                        <?php esc_html_e('Apply Code', 'geo-ia-optimisation-alloia'); ?>
                    </button>
                </div>
                <div id="partner_code_status" style="margin-top:10px;"></div>
            </div>
        </div>

    <?php else: ?>
        <!-- Pro user content - Keep the same card design but show subscribed status -->
        <div class="notice notice-success is-dismissible">
            <p><strong><?php esc_html_e('Pro License Active!', 'geo-ia-optimisation-alloia'); ?></strong> <?php esc_html_e('Your subscriptions are active and your API key is configured.', 'geo-ia-optimisation-alloia'); ?></p>
        </div>
        
        <!-- Active subscription cards with "Subscribed" status -->
        <div class="alloia-card alloia-analytics-grid">
            <div class="alloia-analytics-card">
                <div style="text-align:center;margin-bottom:15px;">
                    <div style="width:60px;height:60px;background:#e6f5ea;border-radius:50%;margin:0 auto 10px;display:flex;align-items:center;justify-content:center;">
                        <span class="dashicons dashicons-admin-site-alt3" style="font-size:24px;color:#4caf50;"></span>
                    </div>
                </div>
                <h4>AI Alternative Site</h4>
                <p style="color:#007cba;font-weight:600;margin:10px 0;">Optimized AI Knowledge Graph Rendering</p>
                <div style="font-size:24px;font-weight:bold;color:#4caf50;margin:15px 0;">Starting from $250/month</div>
                <p style="margin:15px 0;color:#646970;">Zero impact on site SEO, dynamically adapts content for each AI and LLM</p>
                <ul style="text-align:left;margin:15px 0;color:#646970;font-size:14px;">
                    <li>• ≤1000 SKU: $250/month</li>
                    <li>• ≤5000 SKU: $400/month</li>
                    <li>• ≤10000 SKU: $700/month + $140/month per 10K additional</li>
                    <li>• 10K free queries/month, premium levels available</li>
                </ul>
                <button class="button button-secondary" disabled style="background:#46b450;color:white;border:none;">
                    <span class="dashicons dashicons-yes-alt" style="margin-right:5px;"></span>
                    <?php esc_html_e('Subscribed', 'geo-ia-optimisation-alloia'); ?>
                </button>
            </div>
        </div>

        <!-- Partner Code Section for Pro Users -->
        <div class="alloia-card alloia-setting-group" style="margin-top:20px;">
            <div class="alloia-setting-info">
                <strong><?php esc_html_e('Partner Code (Optional)', 'geo-ia-optimisation-alloia'); ?></strong>
                <p><?php esc_html_e('Enter here the code provided by your agency or AlloIA partner, it will link this website to them and make support from them more easy.', 'geo-ia-optimisation-alloia'); ?></p>
                <div style="display:flex;gap:10px;align-items:center;margin-top:10px;">
                    <input type="text" id="partner_code_pro" placeholder="<?php esc_attr_e('Enter partner code...', 'geo-ia-optimisation-alloia'); ?>" class="regular-text" style="min-width:300px;" />
                    <button type="button" id="apply_partner_code_pro" class="button button-secondary">
                        <?php esc_html_e('Apply Code', 'geo-ia-optimisation-alloia'); ?>
                    </button>
                </div>
                <div id="partner_code_status_pro" style="margin-top:10px;"></div>
            </div>
        </div>
    <?php endif; ?>

    <!-- API Key Management - Always visible -->
    <div class="alloia-card alloia-setting-group" style="margin-top:30px;">
        <div class="alloia-setting-info">
            <?php if ($data['is_pro']): ?>
                <strong><?php esc_html_e('API Key Management', 'geo-ia-optimisation-alloia'); ?></strong>
                <p><?php esc_html_e('Your current API key is active. You can update it below if needed.', 'geo-ia-optimisation-alloia'); ?></p>
                <form method="post" action="" style="display:flex;gap:10px;align-items:center;margin-top:10px;">
                    <?php wp_nonce_field('alloia_license_activation', 'alloia_license_nonce'); ?>
                    <input type="text" name="license_key" value="<?php echo esc_attr(get_option('alloia_api_key', '')); ?>" class="regular-text" style="min-width:300px;" />
                    <input type="submit" name="activate_license" value="<?php esc_attr_e('Update Key', 'geo-ia-optimisation-alloia'); ?>" class="button button-secondary" />
                </form>
            <?php else: ?>
                <strong><?php esc_html_e('Already have an API key?', 'geo-ia-optimisation-alloia'); ?></strong>
                <p><?php esc_html_e('If you already have an AlloIA API key, enter it below to activate Pro features immediately.', 'geo-ia-optimisation-alloia'); ?></p>
                <form method="post" action="" style="display:flex;gap:10px;align-items:center;margin-top:10px;">
                    <?php wp_nonce_field('alloia_license_activation', 'alloia_license_nonce'); ?>
                    <input type="text" name="license_key" placeholder="<?php esc_attr_e('Enter your API key...', 'geo-ia-optimisation-alloia'); ?>" class="regular-text" style="min-width:300px;" />
                    <input type="submit" name="activate_license" value="<?php esc_attr_e('Activate', 'geo-ia-optimisation-alloia'); ?>" class="button button-primary" />
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.alloia-settings-form {
    margin-top: 20px;
}

.alloia-features-status .feature-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 15px;
    padding: 10px 0;
    border-bottom: 1px solid #f0f0f1;
}

.alloia-features-status .feature-item:last-child {
    border-bottom: none;
}

.alloia-features-status .feature-item .dashicons {
    margin-right: 10px;
    margin-top: 2px;
    flex-shrink: 0;
}

.alloia-features-status .feature-item strong {
    display: block;
    margin-bottom: 5px;
}

.alloia-features-status .feature-item p {
    margin: 0;
    color: #646970;
    font-size: 14px;
}

.alloia-card {
    margin-bottom: 25px;
}

.alloia-card h3 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.alloia-card .description {
    color: #646970;
    font-style: italic;
    margin-bottom: 20px;
}

.notice.inline {
    display: inline-block;
    margin: 0;
    padding: 5px 10px;
    font-size: 14px;
}

.notice.inline p {
    margin: 0;
}
</style>

<!-- Subscription Modal -->
<div id="subscription-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2><?php esc_html_e('Subscribe to AlloIA', 'geo-ia-optimisation-alloia'); ?></h2>
        
        <form method="post" id="subscription-form">
            <?php wp_nonce_field('alloia_subscription', 'alloia_subscription_nonce'); ?>
            <input type="hidden" name="plan_id" id="selected_plan_id">
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="customer_email"><?php esc_html_e('Email Address', 'geo-ia-optimisation-alloia'); ?></label>
                    </th>
                    <td>
                        <input type="email" name="customer_email" id="customer_email" class="regular-text" required>
                        <p class="description"><?php esc_html_e('We\'ll use this email for your AlloIA account and billing communications.', 'geo-ia-optimisation-alloia'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="company_name"><?php esc_html_e('Company Name', 'geo-ia-optimisation-alloia'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="company_name" id="company_name" class="regular-text">
                        <p class="description"><?php esc_html_e('Optional: Your company or organization name.', 'geo-ia-optimisation-alloia'); ?></p>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <input type="submit" name="alloia_subscribe" class="button button-primary" value="<?php esc_attr_e('Proceed to Checkout', 'geo-ia-optimisation-alloia'); ?>">
            </p>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Subscribe buttons are now direct links, no JavaScript handling needed
    
    // Close modal
    $('.close').on('click', function() {
        $('#subscription-modal').hide();
    });
    
    // Close modal when clicking outside
    $(window).on('click', function(e) {
        if ($(e.target).is('#subscription-modal')) {
            $('#subscription-modal').hide();
        }
    });
    
    // Handle subscription form submission
    $('#subscription-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $submitButton = $form.find('input[type="submit"]');
        var originalText = $submitButton.val();
        
        // Disable submit button and show loading
        $submitButton.prop('disabled', true).val('Redirecting...');
        
        // Get form data
        var formData = new FormData(this);
        formData.append('action', 'alloia_create_checkout_session');
        formData.append('alloia_subscription_nonce', '<?php echo esc_attr(wp_create_nonce("alloia_subscription")); ?>');
        
        // Submit form via AJAX
        $.ajax({
            url: '<?php echo esc_url(admin_url("admin-ajax.php")); ?>',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    // Show success message
                    $('<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>')
                        .insertBefore($form);
                    
                    // Redirect to AlloIA.ai billing page
                    setTimeout(function() {
                        window.location.href = response.data.redirect_url;
                    }, 2000);
                } else {
                    // Show error message
                    $('<div class="notice notice-error is-dismissible"><p>Error: ' + response.data + '</p></div>')
                        .insertBefore($form);
                }
            },
            error: function() {
                // Show generic error message
                $('<div class="notice notice-error is-dismissible"><p>An error occurred. Please try again.</p></div>')
                    .insertBefore($form);
            },
            complete: function() {
                // Re-enable submit button
                $submitButton.prop('disabled', false).val(originalText);
            }
        });
    });
    
    // Partner Code functionality
    var partnerCode = '';
    
    // Handle Apply Code button for non-pro users
    $('#apply_partner_code').on('click', function() {
        var code = $('#partner_code').val().trim();
        if (code) {
            partnerCode = code;
            $('#partner_code_status').html('<div class="notice notice-success inline"><p><strong>Partner code applied:</strong> ' + code + '</p></div>');
            updateSubscriptionLinks();
        } else {
            $('#partner_code_status').html('<div class="notice notice-error inline"><p>Please enter a partner code.</p></div>');
        }
    });
    
    // Handle Apply Code button for pro users
    $('#apply_partner_code_pro').on('click', function() {
        var code = $('#partner_code_pro').val().trim();
        if (code) {
            partnerCode = code;
            $('#partner_code_status_pro').html('<div class="notice notice-success inline"><p><strong>Partner code applied:</strong> ' + code + '</p></div>');
            // For pro users, we could save this to database or show confirmation
        } else {
            $('#partner_code_status_pro').html('<div class="notice notice-error inline"><p>Please enter a partner code.</p></div>');
        }
    });
    
    // Function to update subscription links with partner code
    function updateSubscriptionLinks() {
        $('a[href*="alloia.ai/dashboard/billing"]').each(function() {
            var href = $(this).attr('href');
            var url = new URL(href);
            
            if (partnerCode) {
                url.searchParams.set('ref', partnerCode);
            } else {
                url.searchParams.delete('ref');
            }
            
            $(this).attr('href', url.toString());
        });
    }

});
</script>