<?php
/**
 * Free Features Template
 * 
 * @package AlloIA_WooCommerce
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<form method="post" action="">
    <?php wp_nonce_field('alloia_settings', 'alloia_nonce'); ?>
    
    <!-- Step 1: AI-Ready Score (medium compact) -->
    <div class="alloia-card alloia-preview" style="margin-top:10px;">
        <h3>Step 1 — AI‑Ready Score</h3>
        <?php $score = isset($data['ai_ready_score']['percentage']) ? intval($data['ai_ready_score']['percentage']) : 0; ?>
        <?php $scoreColor = ($score >= 50) ? '#e6f5ea' : '#fdecea'; $scoreBorder = ($score >= 50) ? '#b7e3c4' : '#f5c2c7'; $scoreText = ($score >= 50) ? '#2e7d32' : '#b00020'; ?>
        <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin:10px 0 12px 0;">
            <span style="background:<?php echo esc_attr($scoreColor); ?>;border:1px solid <?php echo esc_attr($scoreBorder); ?>;color:<?php echo esc_attr($scoreText); ?>;border-radius:22px;padding:10px 16px;font-weight:700;">Score: <?php echo esc_html($score); ?>%</span>
            <?php
                $chip = function($label,$ok){
                    $bg = $ok ? '#e6f5ea' : '#fdecea';
                    $bd = $ok ? '#b7e3c4' : '#f5c2c7';
                    $tx = $ok ? '#2e7d32' : '#b00020';
                    echo '<span style="background:'.esc_attr($bg).';border:1px solid '.esc_attr($bd).';color:'.esc_attr($tx).';border-radius:22px;padding:8px 14px;">'.esc_html($label).': '.($ok?'Yes':'No').'</span>';
                };
                $chip('Sitemap', !empty($data['robots_audit']['sitemap_exists']));
                $chip('robots.txt', !empty($data['robots_audit']['robots_exists']));
                $chip('llms.txt', !empty($data['robots_audit']['llms_exists']));
                $chip('AlloIA graph', !empty($data['robots_audit']['graph_enabled']));
            ?>
            <?php if (!empty($data['robots_audit']['training_bots_total'])): ?>
            <?php $bg='#f6f7f7';$bd='#e1e3e4';$tx='#222'; ?>
            <span style="background:<?php echo esc_attr($bg); ?>;border:1px solid <?php echo esc_attr($bd); ?>;border-radius:22px;padding:8px 14px;">AI blocked: <?php echo intval($data['robots_audit']['training_bots_blocked']); ?>/<?php echo intval($data['robots_audit']['training_bots_total']); ?></span>
            <?php endif; ?>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:6px;">
            <form method="post" action="" style="display:inline;">
                <?php wp_nonce_field('alloia_run_audit_action', 'alloia_run_audit_nonce'); ?>
                <input type="hidden" name="alloia_run_audit" value="1" />
                <input type="submit" class="button button-primary" value="Run Audit Now" />
            </form>
        </div>
    </div>

    <!-- Container for subsequent steps -->
    <div class="alloia-toggles">
        
        <!-- Step 2: robots.txt generation + Training permission (default selector) -->
        <div class="alloia-card alloia-setting-group">
            <div class="alloia-toggle">
                <div class="alloia-setting-info">
                    <strong>Step 2 — Generate robots.txt</strong>
                    <p>Create or refresh an AI-friendly <code>robots.txt</code> based on your settings, and choose whether to allow AI training bots.</p>

                    <form method="post" action="" style="margin-top:10px;display:flex;gap:16px;align-items:center;flex-wrap:wrap;">
                        <?php wp_nonce_field('alloia_save_llm_training', 'alloia_llm_training_nonce'); ?>
                        <label><input type="radio" name="alloia_llm_training" value="allow" <?php checked('allow', get_option('alloia_llm_training', 'allow')); ?> /> Allow training</label>
                        <label><input type="radio" name="alloia_llm_training" value="disallow" <?php checked('disallow', get_option('alloia_llm_training', 'allow')); ?> /> Disallow training</label>
                        <input type="submit" class="button" value="Save policy" />
                    </form>

                    <div style="margin-top:10px; display:flex; gap:10px; flex-wrap:wrap;">
                        <form method="post" action="" style="display:inline;">
                            <?php wp_nonce_field('alloia_update_robots', 'alloia_update_robots_nonce'); ?>
                            <input type="hidden" name="alloia_update_robots_now" value="1" />
                            <input type="submit" class="button button-primary" value="Generate robots.txt" />
                            <a href="<?php echo esc_url(home_url('/robots.txt')); ?>" target="_blank" class="button">View robots.txt →</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Step 3: generic llms.txt generation (before enabling AlloIA OSS) -->
        <div class="alloia-card alloia-setting-group">
            <div class="alloia-toggle">
                <div class="alloia-setting-info">
                    <strong>Step 3 — Generate AI-optimized llms.txt</strong>
                    <p>Generate a comprehensive <code>llms.txt</code> file using the <a href="https://alloia.io/api/tools/llms-txt" target="_blank">AlloIA.io API</a> for optimal AI model consumption. This creates a detailed, site-specific llms.txt file that helps AI systems better understand your content.</p>
                    <div style="margin-top:10px; display:flex; gap:10px; flex-wrap:wrap;">
                        <form method="post" action="" style="display:inline;">
                            <?php wp_nonce_field('generate_llms_txt_action', 'generate_llms_txt_nonce'); ?>
                            <input type="hidden" name="generate_llms_txt" value="1" />
                            <input type="submit" class="button button-primary" value="Generate llms.txt" />
                            <a href="<?php echo esc_url(home_url('/llms.txt')); ?>" target="_blank" class="button">View llms.txt →</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- No global save button needed for one-time actions -->

    <!-- AlloIA Tools & Services -->
    <div class="alloia-card alloia-preview" style="margin-top:30px;">
        <h2>Outils gratuits AlloIA</h2>
        <p>Découvrez nos outils gratuits pour optimiser votre présence dans l'ère de l'IA générative :</p>
        
        <div class="alloia-links-grid" style="display:grid;gap:20px;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));margin-top:20px;">
            <!-- PERSPECTIVE -->
            <div class="alloia-feature-box" style="border:1px solid #e1e3e4;border-radius:8px;padding:20px;background:#fff;">
                <h4>🔍 PERSPECTIVE - Analyse de compatibilité IA</h4>
                <p>Entrez l'URL de votre site pour obtenir un score GEO et des recommandations.</p>
                <a href="https://alloia.ai/geo/perspective" target="_blank" class="button" style="background-color:#15c0ea;border-color:#15c0ea;color:#fff;">Analyser mon site</a>
            </div>
            
            <!-- ACTIONS -->
            <div class="alloia-feature-box" style="border:1px solid #e1e3e4;border-radius:8px;padding:20px;background:#fff;">
                <h4>📋 ACTIONS - Questionnaire GEO</h4>
                <p>Auto-évaluez votre maturité et obtenez des recommandations.</p>
                <a href="https://alloia.ai/geo/actions" target="_blank" class="button" style="background-color:#15c0ea;border-color:#15c0ea;color:#fff;">Commencer l'évaluation</a>
            </div>
            
            <!-- PULSE -->
            <div class="alloia-feature-box" style="border:1px solid #e1e3e4;border-radius:8px;padding:20px;background:#fff;">
                <h4>📊 PULSE - Surveillance IA concurrentielle</h4>
                <p>Surveillez votre visibilité sur ChatGPT, Perplexity, Claude et Google AI avec des analytics concurrentiels inégalés.</p>
                <a href="https://alloia.ai/geo/pulse" target="_blank" class="button" style="background-color:#15c0ea;border-color:#15c0ea;color:#fff;">Accéder à PULSE</a>
            </div>
        </div>
    </div>

</form> 