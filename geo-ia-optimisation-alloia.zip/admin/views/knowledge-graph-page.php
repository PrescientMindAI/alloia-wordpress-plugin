<?php
/**
 * AlloIA Knowledge Graph Export Page
 * 
 * @package AlloIA_WooCommerce
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Use data passed from the admin class (safer approach)
$api_key = get_option('alloia_api_key', '');
$has_access = isset($data['has_access']) ? $data['has_access'] : false;
$exporter = isset($data['exporter']) ? $data['exporter'] : null;
$subscription_manager = isset($data['subscription_manager']) ? $data['subscription_manager'] : null;

// Fallback initialization if data not passed (for backward compatibility)
if (!$exporter && !empty($api_key)) {
    $api_client = new AlloIA_API($api_key);
    $subscription_manager = new AlloIA_Subscription_Manager($api_client);
    $exporter = new AlloIA_Knowledge_Graph_Exporter($api_client, $subscription_manager);
$has_access = $subscription_manager->has_plan('graph') || $subscription_manager->has_plan('enterprise');
}

// Handle debug actions
if (current_user_can('manage_options') && isset($_GET['debug_action']) && $subscription_manager) {
    $debug_action = sanitize_text_field(wp_unslash($_GET['debug_action']));
    switch ($debug_action) {
        case 'set_enterprise_plan':
            // Manually set enterprise plan to bypass rate limiting
            set_transient('alloia_subscription_cache', array(
                'is_active' => true,
                'plan_key' => 'enterprise',
                'cached_at' => time(),
                'source' => 'manual_override'
            ), 3600); // Cache for 1 hour
            echo '<div class="notice notice-success"><p>Enterprise plan manually set to bypass rate limiting!</p></div>';
            $has_access = true; // Update current page access
            break;
        case 'set_graph_plan':
            $subscription_manager->set_subscription_status('graph', 'active');
            echo '<div class="notice notice-success"><p>Graph plan manually set for testing!</p></div>';
            break;
        case 'clear_cache':
            $subscription_manager->clear_subscription_cache();
            echo '<div class="notice notice-success"><p>Cache cleared!</p></div>';
            break;
    }
}

// Debug subscription status (temporary)
if (current_user_can('manage_options') && isset($_GET['debug_subscription']) && $subscription_manager) {
    echo '<div class="notice notice-info"><h4>Debug Subscription Status:</h4>';
    
    // Show debug actions
    echo '<h5>Debug Actions:</h5>';
    echo '<p>';
    $current_uri = isset($_SERVER['REQUEST_URI']) ? esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])) : '';
    echo '<a href="' . esc_url(add_query_arg(['debug_action' => 'set_enterprise_plan'], $current_uri)) . '" class="button button-primary">✅ Set Enterprise Plan</a> ';
    echo '<a href="' . esc_url(add_query_arg(['debug_action' => 'set_graph_plan'], $current_uri)) . '" class="button">Set Graph Plan (Test)</a> ';
    echo '<a href="' . esc_url(add_query_arg(['debug_action' => 'clear_cache'], $current_uri)) . '" class="button">Clear All Cache</a> ';
    echo '</p>';
    
    // Check cached subscription data
    echo '<h5>Cached Subscription Data:</h5>';
    $cached_subscription = get_transient('alloia_subscription_cache');
    if ($cached_subscription) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            echo '<pre>Cached Data: ' . esc_html(print_r($cached_subscription, true)) . '</pre>';
        }
    } else {
        echo '<p>No cached subscription data</p>';
    }
    
    // Check API status
    echo '<h5>API Status Check:</h5>';
    try {
        $api_status = $subscription_manager->check_subscription_status();
        echo '<pre>API Response: ' . esc_html(print_r($api_status, true)) . '</pre>';
    } catch (Exception $e) {
        echo '<p>API Error: ' . esc_html($e->getMessage()) . '</p>';
        if (strpos($e->getMessage(), 'Rate limit exceeded') !== false) {
            echo '<p><strong>This is a rate limit error - the subscription might still be valid!</strong></p>';
        }
    }
    
    // Check local status
    echo '<h5>Local Status:</h5>';
    try {
        $debug_status = $subscription_manager->get_local_subscription_status();
        echo '<pre>Local Data: ' . esc_html(print_r($debug_status, true)) . '</pre>';
    } catch (Exception $e) {
        echo '<p>Local Status Error: ' . esc_html($e->getMessage()) . '</p>';
    }
    
    echo '<h5>Plan Checks:</h5>';
    try {
        echo '<p>has_plan(\'graph\'): ' . ($subscription_manager->has_plan('graph') ? 'YES' : 'NO') . '</p>';
        echo '<p>has_plan(\'enterprise\'): ' . ($subscription_manager->has_plan('enterprise') ? 'YES' : 'NO') . '</p>';
    } catch (Exception $e) {
        echo '<p>Plan Check Error: ' . esc_html($e->getMessage()) . '</p>';
    }
    echo '<p>API Key: ' . (empty($api_key) ? 'NOT SET' : 'SET (' . esc_html(strlen($api_key)) . ' chars)') . '</p>';
    
    
    echo '</div>';
}

// Debug products if requested
if (current_user_can('manage_options') && isset($_GET['debug_products'])) {
    echo '<div class="notice notice-info"><h4>Debug Products:</h4>';
    
    // Check WooCommerce
    echo '<h5>WooCommerce Status:</h5>';
    echo '<p>WooCommerce Active: ' . (class_exists('WooCommerce') ? 'YES' : 'NO') . '</p>';
    echo '<p>wc_get_product function: ' . (function_exists('wc_get_product') ? 'YES' : 'NO') . '</p>';
    
    // Direct product count
    echo '<h5>Direct Product Query:</h5>';
    $direct_args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 5,
        'fields' => 'ids'
    );
    $direct_posts = get_posts($direct_args);
    echo '<p>Direct Query Found: ' . count($direct_posts) . ' products</p>';
    
    if (!empty($direct_posts)) {
        echo '<h6>Sample Product IDs:</h6>';
        echo '<ul>';
        foreach (array_slice($direct_posts, 0, 3) as $product_id) {
            $product = wc_get_product($product_id);
            if ($product) {
                echo '<li>ID: ' . esc_html($product_id) . ' - Name: ' . esc_html($product->get_name()) . ' - Price: ' . esc_html($product->get_price()) . '</li>';
            } else {
                echo '<li>ID: ' . esc_html($product_id) . ' - FAILED to create WC_Product</li>';
            }
        }
        echo '</ul>';
    }
    
    // Test the extract method
    if ($exporter) {
        echo '<h5>Extract Method Test:</h5>';
        try {
            $extracted = $exporter->extract_woocommerce_products(array());
            echo '<p>Extracted Products: ' . count($extracted) . '</p>';
        } catch (Exception $e) {
            echo '<p>Extract Error: ' . esc_html($e->getMessage()) . '</p>';
        }
    }
    
    echo '</div>';
}

// Get export statistics (with error handling)
$export_stats = array('total_exported' => 0, 'total_failed' => 0, 'last_export' => null);
$batch_size = 50;

if ($exporter) {
    try {
        $export_stats = $exporter->get_export_statistics();
        $batch_size = $exporter->get_batch_size();
    } catch (Exception $e) {
        // Log error but don't crash
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('AlloIA Knowledge Graph: Failed to get export stats: ' . $e->getMessage());
        }
    }
}

// Handle form submissions
if (isset($_POST['alloia_export_products']) && check_admin_referer('alloia_export_products', 'alloia_export_products_nonce')) {
    if (current_user_can('manage_options') && $has_access && $exporter) {
        $filters = array();
        
        // Handle excluded categories
        if (!empty($_POST['exclude_category']) && is_array($_POST['exclude_category'])) {
            $filters['exclude_category'] = array_map('intval', $_POST['exclude_category']);
        }
        
        // Handle product type inclusions (default to checked values)
        $filters['include_inactive'] = isset($_POST['include_inactive']) ? 1 : 0;
        $filters['include_virtual'] = isset($_POST['include_virtual']) ? 1 : 0;
        $filters['include_out_of_stock'] = isset($_POST['include_out_of_stock']) ? 1 : 0;
        
        $background = isset($_POST['background_export']);
        
        try {
            $export_result = $exporter->export_products($filters, $background);
            
            if ($export_result['success']) {
                $success_message = $export_result['message'];
                if ($background) {
                    $success_message .= ' Export ID: ' . $export_result['export_id'];
                }
            } else {
                $error_message = $export_result['message'];
                
                // Add detailed error information if available
                if (!empty($export_result['errors'])) {
                    $error_message .= '<br><strong>Detailed Errors:</strong><ul>';
                    foreach ($export_result['errors'] as $error) {
                        $error_message .= '<li>' . esc_html($error) . '</li>';
                    }
                    $error_message .= '</ul>';
                }
            }
        } catch (Exception $e) {
            $error_message = 'Export failed: ' . $e->getMessage();
        }
    } else {
        if (!$exporter) {
            $error_message = 'Export service not available. Please check your API key and try again.';
    } else {
        $error_message = 'You do not have permission to export products or do not have an active subscription.';
        }
    }
}

// Handle batch size update
if (isset($_POST['alloia_update_batch_size']) && check_admin_referer('alloia_update_batch_size', 'alloia_update_batch_size_nonce') && $exporter) {
    if (current_user_can('manage_options')) {
        $new_batch_size = intval($_POST['batch_size']);
        if ($new_batch_size > 0 && $new_batch_size <= 1000) {
            $exporter->set_batch_size($new_batch_size);
            $batch_size = $new_batch_size;
            $success_message = 'Batch size updated successfully';
        } else {
            $error_message = 'Batch size must be between 1 and 1000';
        }
    }
}

// Get product categories for filter
$product_categories = get_terms(array(
    'taxonomy' => 'product_cat',
    'hide_empty' => false,
    'orderby' => 'name'
));

// Get total product count
$total_products = wp_count_posts('product')->publish;
?>

<div class="wrap alloia-knowledge-graph">
    <h1>
        <span class="dashicons dashicons-networking" style="margin-right:8px;"></span>
        <?php esc_html_e('AlloIA Knowledge Graph Export', 'geo-ia-optimisation-alloia'); ?>
    </h1>
    
    <?php if (isset($error_message)): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php echo wp_kses($error_message, array('br' => array(), 'strong' => array(), 'ul' => array(), 'li' => array())); ?></p>
        </div>
    <?php endif; ?>
    
    <?php if (isset($success_message)): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php echo esc_html($success_message); ?></p>
        </div>
    <?php endif; ?>
    
    <!-- Access Check -->
    <?php if (!$has_access): ?>
        <div class="notice notice-info">
            <p><strong><?php esc_html_e('Knowledge Graph Export requires an active Graph Plan or Enterprise Plan subscription.', 'geo-ia-optimisation-alloia'); ?></strong></p>
            <p><?php esc_html_e('Please visit the Subscription page to upgrade your plan and unlock this feature.', 'geo-ia-optimisation-alloia'); ?></p>
            <p><a href="<?php echo esc_url(admin_url('admin.php?page=alloia-settings&tab=subscription')); ?>" class="button button-primary"><?php esc_html_e('View Subscription Plans', 'geo-ia-optimisation-alloia'); ?></a></p>
        </div>
    <?php endif; ?>
    
    <!-- Export Summary -->
    <div style="background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px; padding: 12px 16px; margin: 20px 0; display: inline-block;">
        <span style="font-size: 16px; color: #646970;">
            <strong style="color: #0073aa;"><?php echo esc_html($export_stats['total_exported']); ?> products exported</strong> / <?php echo esc_html($total_products); ?> products in store
        </span>
    </div>
    
    <!-- Export Configuration -->
    <?php if ($has_access): ?>
        <div class="alloia-setting-group">
            <h2><?php esc_html_e('Export Configuration', 'geo-ia-optimisation-alloia'); ?></h2>
            
            <form method="post" id="export-form">
                <?php wp_nonce_field('alloia_export_products', 'alloia_export_products_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="exclude_category"><?php esc_html_e('Exclude Categories', 'geo-ia-optimisation-alloia'); ?></label>
                        </th>
                        <td>
                            <select name="exclude_category[]" id="exclude_category" multiple size="5" style="min-width: 250px;">
                                <?php foreach ($product_categories as $category): ?>
                                    <option value="<?php echo esc_attr($category->term_id); ?>">
                                        <?php echo esc_html($category->name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Select categories to exclude from export. Hold Ctrl/Cmd to select multiple. Leave empty to include all categories.', 'geo-ia-optimisation-alloia'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php esc_html_e('Product Types', 'geo-ia-optimisation-alloia'); ?></th>
                        <td>
                            <fieldset>
                                <label>
                                    <input type="checkbox" name="include_inactive" value="1">
                                    <?php esc_html_e('Include inactive products (draft, private, etc.)', 'geo-ia-optimisation-alloia'); ?>
                                </label>
                                <br><br>
                                <label>
                                    <input type="checkbox" name="include_virtual" value="1" checked>
                                    <?php esc_html_e('Include virtual products', 'geo-ia-optimisation-alloia'); ?>
                                </label>
                                <br><br>
                                <label>
                                    <input type="checkbox" name="include_out_of_stock" value="1" checked>
                                    <?php esc_html_e('Include out of stock products', 'geo-ia-optimisation-alloia'); ?>
                                </label>
                            </fieldset>
                            <p class="description"><?php esc_html_e('By default, all product types are included except inactive products. Uncheck to exclude specific types.', 'geo-ia-optimisation-alloia'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="background_export"><?php esc_html_e('Export Mode', 'geo-ia-optimisation-alloia'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="background_export" id="background_export" value="1">
                                <?php esc_html_e('Run export in background (recommended for large catalogs)', 'geo-ia-optimisation-alloia'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Background exports are processed asynchronously and won\'t block your browser.', 'geo-ia-optimisation-alloia'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="alloia_export_products" class="button button-primary" value="<?php esc_attr_e('Export Products to Knowledge Graph', 'geo-ia-optimisation-alloia'); ?>">
                </p>
            </form>
        </div>
        
        <!-- Recent Export Activity -->
        <div class="card">
            <h2><?php esc_html_e('Recent Export Activity', 'geo-ia-optimisation-alloia'); ?></h2>
            
            <div class="export-activity-grid">
                <div class="activity-item">
                    <div class="activity-content">
                        <h4><?php esc_html_e('Last Export', 'geo-ia-optimisation-alloia'); ?></h4>
                        <p class="activity-value"><?php echo esc_html($export_stats['last_export'] ? wp_date('F j, Y \a\t g:i A', strtotime($export_stats['last_export'])) : 'Never'); ?></p>
                    </div>
                </div>
                
                <?php if ($export_stats['total_failed'] > 0): ?>
                <div class="activity-item">
                    <div class="activity-content">
                        <h4><?php esc_html_e('Export Failures', 'geo-ia-optimisation-alloia'); ?></h4>
                        <p class="activity-value"><?php echo esc_html($export_stats['total_failed']); ?> failed exports</p>
                        <p class="activity-note">Check logs for details</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
    <?php endif; ?>
</div>

<style>
.export-activity-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.activity-item {
    display: flex;
    align-items: flex-start;
    padding: 20px;
    background: #f9f9f9;
    border-radius: 4px;
    border: 1px solid #ddd;
}

.activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #0073aa;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 15px;
    flex-shrink: 0;
}

.activity-icon.error {
    background: #d63638;
}

.activity-icon .dashicons {
    color: white;
    font-size: 20px;
}

.activity-content h4 {
    margin: 0 0 8px 0;
    color: #1d2327;
    font-size: 16px;
}

.activity-value {
    margin: 0 0 5px 0;
    font-size: 18px;
    font-weight: bold;
    color: #0073aa;
}

.activity-note {
    margin: 0;
    font-size: 13px;
    color: #646970;
    font-style: italic;
}

.export-history {
    padding: 20px;
    background: #f9f9f9;
    border-radius: 4px;
    text-align: center;
    color: #646970;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Form validation
    $('#export-form').on('submit', function(e) {
        // Show confirmation for large exports
        var excludedCategories = $('#exclude_category').val() || [];
        var background = $('#background_export').is(':checked');
        
        if (excludedCategories.length === 0 && !background) {
            var totalProducts = <?php echo intval($total_products); ?>;
            if (totalProducts > 1000) {
                if (!confirm('<?php esc_js(__('You are about to export all products to the knowledge graph. This may take a long time and could impact your site performance. Consider using background export. Continue anyway?', 'geo-ia-optimisation-alloia')); ?>')) {
                    e.preventDefault();
                    return false;
                }
            }
        }
    });
});
</script>

<?php include ALLOIA_PLUGIN_PATH . 'admin/views/dashboard-styles-scripts.php'; ?>