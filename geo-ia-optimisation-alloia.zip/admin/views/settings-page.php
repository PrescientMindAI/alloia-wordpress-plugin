<?php
/**
 * AlloIA Settings Page Template
 * 
 * @package AlloIA_WooCommerce
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap alloia-settings" style="max-width:1000px;">
    <h1 style="display:flex;align-items:center;">
        <img src="<?php echo esc_url(plugin_dir_url(__DIR__) . '../assets/alloia_svg.svg'); ?>" alt="AlloIA" style="height:40px;margin-right:12px;">
        for WooCommerce
    </h1>
    <p>Welcome to AlloIA! Transform your WooCommerce store for the AI era. 
       <a href="https://alloia.org" target="_blank">Learn about our open-source protocol</a>
    </p>
    
    <!-- Navigation Tabs -->
    <h2 class="nav-tab-wrapper">
        <a href="?page=alloia-settings&tab=free" 
           class="nav-tab <?php echo $data['active_tab'] == 'free' ? 'nav-tab-active' : ''; ?>">
            🆓 Free Features
        </a>
        <a href="?page=alloia-settings&tab=pro" 
           class="nav-tab <?php echo $data['active_tab'] == 'pro' ? 'nav-tab-active' : ''; ?>">
            ⭐ Pro Features
        </a>
    </h2>
    
    <!-- Tab Content -->
    <div class="tab-content" style="padding:20px 0;">
        <?php $__tab = isset($data['active_tab']) ? strtolower($data['active_tab']) : 'free'; ?>
        <?php if ($__tab === 'pro') { 
            include ALLOIA_PLUGIN_PATH . 'admin/views/pro-features.php';
        } else {
            include ALLOIA_PLUGIN_PATH . 'admin/views/free-features.php';
        } ?>
    </div>
</div> 