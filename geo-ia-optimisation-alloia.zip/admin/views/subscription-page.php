<?php
/**
 * AlloIA Subscription Management Page
 * 
 * @package AlloIA_WooCommerce
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Data is prepared by the admin class and passed as $data
// Extract the data for easier access
$subscription_status = $data['subscription_status'];
$usage_info = $data['usage_info'];
$available_plans = $data['available_plans'];

// Check if there was an error
$has_error = isset($subscription_status['error']);
$error_message = $has_error ? $subscription_status['error'] : '';
?>

<div class="wrap">
    <h1><?php esc_html_e('AlloIA Subscription Management', 'geo-ia-optimisation-alloia'); ?></h1>
    
    <?php if ($has_error): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php echo esc_html($error_message); ?></p>
        </div>
    <?php endif; ?>
    
    <!-- Current Subscription Status -->
    <div class="card">
        <h2><?php esc_html_e('Current Subscription Status', 'geo-ia-optimisation-alloia'); ?></h2>
        
        <?php if ($subscription_status['is_active']): ?>
            <div class="subscription-active">
                <h3><?php esc_html_e('Active Subscription', 'geo-ia-optimisation-alloia'); ?></h3>
                <p><strong><?php esc_html_e('Plan:', 'geo-ia-optimisation-alloia'); ?></strong> <?php echo esc_html($subscription_status['plan']['name'] ?? 'Unknown'); ?></p>
                <p><strong><?php esc_html_e('Status:', 'geo-ia-optimisation-alloia'); ?></strong> <?php echo esc_html(ucfirst($subscription_status['status'] ?? 'Unknown')); ?></p>
                <?php if (isset($subscription_status['expires_at']) && $subscription_status['expires_at']): ?>
                    <p><strong><?php esc_html_e('Expires:', 'geo-ia-optimisation-alloia'); ?></strong> <?php echo esc_html($subscription_status['expires_at']); ?></p>
                <?php endif; ?>
                
                <!-- Usage Information -->
                <?php if (!empty($usage_info)): ?>
                <div class="usage-info">
                    <h4><?php esc_html_e('Usage Information', 'geo-ia-optimisation-alloia'); ?></h4>
                    <p><strong><?php esc_html_e('API Calls:', 'geo-ia-optimisation-alloia'); ?></strong> <?php echo esc_html($usage_info['api_calls_used'] ?? 0); ?> / <?php echo esc_html($usage_info['api_calls_limit'] ?? 'Unlimited'); ?></p>
                    <p><strong><?php esc_html_e('Products Exported:', 'geo-ia-optimisation-alloia'); ?></strong> <?php echo esc_html($usage_info['products_exported'] ?? 0); ?> / <?php echo esc_html($usage_info['products_limit'] ?? 'Unlimited'); ?></p>
                </div>
                <?php endif; ?>
                
                <!-- Cancel Subscription -->
                <form method="post" style="margin-top: 20px;">
                    <?php wp_nonce_field('alloia_cancel_subscription', 'alloia_cancel_subscription_nonce'); ?>
                    <input type="submit" name="alloia_cancel_subscription" class="button button-secondary" value="<?php esc_attr_e('Cancel Subscription', 'geo-ia-optimisation-alloia'); ?>" onclick="return confirm('<?php esc_attr_e('Are you sure you want to cancel your subscription?', 'geo-ia-optimisation-alloia'); ?>')">
                </form>
            </div>
        <?php else: ?>
            <div class="subscription-inactive">
                <h3><?php esc_html_e('No Active Subscription', 'geo-ia-optimisation-alloia'); ?></h3>
                <p><?php esc_html_e('You currently don\'t have an active subscription. Subscribe to one of our plans below to unlock Pro features.', 'geo-ia-optimisation-alloia'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Available Plans -->
    <div class="card">
        <h2><?php esc_html_e('Available Subscription Plans', 'geo-ia-optimisation-alloia'); ?></h2>
        
        <?php if (empty($available_plans)): ?>
            <div class="notice notice-info">
                <p><?php esc_html_e('Unable to load subscription plans. Please check your API connection or try refreshing the page.', 'geo-ia-optimisation-alloia'); ?></p>
            </div>
        <?php else: ?>
            <div class="plans-grid">
                <?php foreach ($available_plans as $plan_key => $plan): ?>
                    <div class="plan-card">
                        <h3><?php echo esc_html($plan['name'] ?? 'Unknown Plan'); ?></h3>
                        <div class="plan-price">
                            <span class="currency"><?php echo esc_html($plan['currency'] ?? '$'); ?></span>
                            <span class="amount"><?php echo esc_html($plan['price'] ?? '0'); ?></span>
                            <span class="period">/<?php echo esc_html($plan['billing_period'] ?? 'month'); ?></span>
                        </div>
                        <p class="plan-description"><?php echo esc_html($plan['description'] ?? ''); ?></p>
                        
                        <?php if (!empty($plan['features'])): ?>
                        <ul class="plan-features">
                            <?php foreach ($plan['features'] as $feature): ?>
                                <li><?php echo esc_html($feature); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                        
                        <?php 
                        $current_plan_key = $subscription_status['plan']['key'] ?? '';
                        $is_current_plan = $subscription_status['is_active'] && $current_plan_key === $plan_key;
                        ?>
                        
                        <?php if (!$subscription_status['is_active'] || !$is_current_plan): ?>
                            <button class="button button-primary subscribe-button" data-plan="<?php echo esc_attr($plan['id'] ?? $plan_key); ?>">
                                <?php esc_html_e('Subscribe Now', 'geo-ia-optimisation-alloia'); ?>
                            </button>
                        <?php else: ?>
                            <button class="button button-secondary" disabled>
                                <?php esc_html_e('Current Plan', 'geo-ia-optimisation-alloia'); ?>
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Subscription Form Modal -->
    <div id="subscription-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2><?php esc_html_e('Subscribe to AlloIA', 'geo-ia-optimisation-alloia'); ?></h2>
            
            <form method="post" id="subscription-form">
                <?php wp_nonce_field('alloia_subscription', 'alloia_subscription_nonce'); ?>
                <input type="hidden" name="plan_id" id="selected_plan_id">
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="customer_email"><?php esc_html_e('Email Address', 'geo-ia-optimisation-alloia'); ?></label>
                        </th>
                        <td>
                            <input type="email" name="customer_email" id="customer_email" class="regular-text" required>
                            <p class="description"><?php esc_html_e('We\'ll use this email for your AlloIA account and billing communications.', 'geo-ia-optimisation-alloia'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="company_name"><?php esc_html_e('Company Name', 'geo-ia-optimisation-alloia'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="company_name" id="company_name" class="regular-text">
                            <p class="description"><?php esc_html_e('Optional: Your company or organization name.', 'geo-ia-optimisation-alloia'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="alloia_subscribe" class="button button-primary" value="<?php esc_attr_e('Proceed to Checkout', 'geo-ia-optimisation-alloia'); ?>">
                </p>
            </form>
        </div>
    </div>
</div>

<style>
.plans-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.plan-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    background: #fff;
}

.plan-card h3 {
    margin-top: 0;
    color: #23282d;
}

.plan-price {
    margin: 20px 0;
}

.plan-price .currency {
    font-size: 16px;
    vertical-align: top;
}

.plan-price .amount {
    font-size: 36px;
    font-weight: bold;
    color: #0073aa;
}

.plan-price .period {
    font-size: 16px;
    color: #666;
}

.plan-description {
    color: #666;
    margin-bottom: 20px;
}

.plan-features {
    list-style: none;
    padding: 0;
    margin: 20px 0;
    text-align: left;
}

.plan-features li {
    padding: 5px 0;
    border-bottom: 1px solid #f0f0f0;
}

.plan-features li:before {
    content: "✓";
    color: #46b450;
    font-weight: bold;
    margin-right: 10px;
}

.subscribe-button {
    width: 100%;
    margin-top: 20px;
}

.subscription-active {
    background: #f0f8ff;
    padding: 15px;
    border-radius: 5px;
    border-left: 4px solid #0073aa;
}

.subscription-inactive {
    background: #fff3cd;
    padding: 15px;
    border-radius: 5px;
    border-left: 4px solid #ffc107;
}

.usage-info {
    background: #f9f9f9;
    padding: 15px;
    border-radius: 5px;
    margin-top: 15px;
}

.usage-info h4 {
    margin-top: 0;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: #fefefe;
    margin: 5% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 500px;
    border-radius: 8px;
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Handle subscribe button clicks
    $('.subscribe-button').on('click', function(e) {
        e.preventDefault();
        var planId = $(this).data('plan');
        $('#selected_plan_id').val(planId);
        $('#subscription-modal').show();
    });
    
    // Close modal when clicking on X
    $('.close').on('click', function() {
        $('#subscription-modal').hide();
    });
    
    // Close modal when clicking outside
    $(window).on('click', function(e) {
        if ($(e.target).is('#subscription-modal')) {
            $('#subscription-modal').hide();
        }
    });
    
    // Pre-fill email if available
    var currentUserEmail = '<?php echo esc_js(wp_get_current_user()->user_email); ?>';
    if (currentUserEmail) {
        $('#customer_email').val(currentUserEmail);
    }
});
</script>
