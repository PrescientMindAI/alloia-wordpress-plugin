<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

$alloia_tracking_website_id = get_option('alloia_tracking_website_id', '');
$api_base_url = get_option('alloia_api_base_url', 'https://alloia.io/api/v1');
$alloia_tracking_api_key = get_option('alloia_tracking_api_key', '');
$is_pro = !empty(get_option('alloia_api_key', ''));
?>

<div class="alloia-subscription" style="max-width:800px;">
	<h2>Subscription & Site Registration</h2>
	<p>Register this site with the AlloIA API relay to provision tracking resources securely. Your org API key remains server-side.</p>

	<?php if (!$is_pro): ?>
		<div class="notice notice-warning" style="margin-top:10px;">
			<p><strong>Pro required:</strong> These features are available with an active Pro license. Please activate your license in the <a href="?page=alloia-settings&tab=pro">Pro</a> tab.</p>
		</div>
	<?php endif; ?>

	<div class="alloia-setting-group">
		<strong>Website Status</strong>
		<p>
			<?php if ($alloia_tracking_website_id): ?>
				✅ Registered with AlloIA tracking. Website ID: <code><?php echo esc_html($alloia_tracking_website_id); ?></code>
			<?php else: ?>
				❌ Not registered yet.
			<?php endif; ?>
		</p>
	</div>

	<form method="post" action="" class="alloia-setting-group" <?php echo !$is_pro ? 'style="opacity:.6;pointer-events:none;"' : ''; ?>>
		<?php wp_nonce_field('alloia_site_register', 'alloia_site_register_nonce'); ?>
		<strong>Register Site</strong>
		<p>This will create a website in AlloIA tracking via API relay and store the returned <code>websiteId</code> locally.</p>
		<div style="margin-top:10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
			<input type="submit" class="button button-primary" name="alloia_register_site" value="Register with API Relay" />
		</div>
	</form>

	<form method="post" action="" class="alloia-setting-group" <?php echo !$is_pro ? 'style="opacity:.6;pointer-events:none;"' : ''; ?>>
		<?php wp_nonce_field('alloia_api_settings', 'alloia_api_settings_nonce'); ?>
		<strong>API Settings</strong>
		<p>Configure custom API base URL (leave default unless instructed otherwise).</p>
		<div style="margin-top:10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
			<input type="text" class="regular-text" name="alloia_api_base_url" value="<?php echo esc_attr($api_base_url); ?>" placeholder="https://alloia.io/api/v1" />
			<input type="submit" class="button" name="alloia_save_api" value="Save" />
		</div>
	</form>

	<?php if ($alloia_tracking_website_id): ?>
	<form method="post" action="" class="alloia-setting-group" <?php echo !$is_pro ? 'style="opacity:.6;pointer-events:none;"' : ''; ?>>
		<?php wp_nonce_field('alloia_provision_tracking', 'alloia_provision_tracking_nonce'); ?>
		<strong>Provision Tracking</strong>
		<p>Get a tracking API key and script from API relay for this website and inject the script automatically.</p>
		<div style="margin-top:10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
			<input type="submit" class="button button-primary" name="alloia_do_provision_tracking" value="Provision Tracking" />
			<?php if (!empty($alloia_tracking_api_key)) : ?>
				<span>Current API Key: <code><?php echo esc_html(substr($alloia_tracking_api_key, 0, 6)); ?>••••</code></span>
			<?php endif; ?>
		</div>
	</form>
	<?php endif; ?>

</div>


