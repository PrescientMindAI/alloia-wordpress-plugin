<?php
/**
 * AlloIA Subscription Manager for WooCommerce plugin
 * 
 * @package AlloIA_WooCommerce
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * AlloIA Subscription Manager Class
 * 
 * Handles subscription management, Stripe integration, and plan validation
 */
class AlloIA_Subscription_Manager {
    
    /**
     * API client instance
     */
    private $api_client;
    
    /**
     * Constructor
     * 
     * @param AlloIA_API $api_client API client instance
     */
    public function __construct($api_client = null) {
        $this->api_client = $api_client ?: new AlloIA_API();
    }
    
    /**
     * Get available subscription plans
     * 
     * @return array Available plans
     */
    public function get_available_plans() {
        return array(
            'dashboard' => array(
                'id' => 'price_dashboard_plan',
                'name' => 'Dashboard Plan',
                'description' => 'Basic analytics and GEO tools',
                'price' => 29,
                'currency' => 'USD',
                'billing_period' => 'month',
                'features' => array(
                    'Analytics Dashboard',
                    'AI Bot Tracking',
                    'Basic Performance Metrics',
                    'GEO Analytics'
                )
            ),
            'graph' => array(
                'id' => 'price_graph_plan',
                'name' => 'Graph Plan',
                'description' => 'Advanced knowledge graph access',
                'price' => 79,
                'currency' => 'USD',
                'billing_period' => 'month',
                'features' => array(
                    'Everything in Dashboard Plan',
                    'Knowledge Graph Export',
                    'Product Optimization',
                    'Competitor Analysis',
                    'Advanced Analytics'
                )
            ),
            'enterprise' => array(
                'id' => 'price_enterprise_plan',
                'name' => 'Enterprise Plan',
                'description' => 'Custom solutions and support',
                'price' => 199,
                'currency' => 'USD',
                'billing_period' => 'month',
                'features' => array(
                    'Everything in Graph Plan',
                    'Custom AI Models',
                    'Priority Support',
                    'White-label Solutions',
                    'API Access'
                )
            )
        );
    }
    
    /**
     * Create checkout session for subscription
     * 
     * @param string $plan_id Stripe price ID
     * @param array $customer_data Customer information
     * @return array Response with checkout URL
     * @throws Exception On checkout creation failure
     */
    public function create_checkout_session($plan_id, $customer_data) {
        // Validate customer data
        $this->validate_customer_data($customer_data);
        
        // Prepare checkout data
        $checkout_data = array(
            'customer_email' => sanitize_email($customer_data['email']),
            'plan_id' => sanitize_text_field($plan_id),
            'company_name' => isset($customer_data['company_name']) ? sanitize_text_field($customer_data['company_name']) : '',
            'domain' => wp_parse_url(home_url(), PHP_URL_HOST),
            'return_url' => admin_url('admin.php?page=alloia-settings&tab=subscription'),
            'cancel_url' => admin_url('admin.php?page=alloia-settings&tab=subscription'),
            'success_url' => admin_url('admin.php?page=alloia-settings&tab=subscription&status=success')
        );
        
        try {
            // Create checkout session via AlloIA.ai
            $response = $this->api_client->create_checkout_session($checkout_data);
            
            // Store checkout session data
            update_option('alloia_checkout_session', array(
                'session_id' => $response['session_id'] ?? '',
                'plan_id' => $plan_id,
                'customer_email' => $customer_data['email'],
                'created_at' => current_time('mysql'),
                'status' => 'pending'
            ));
            
            return $response;
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Checkout session creation failed: ' . $e->getMessage());
            }
            throw new Exception('Failed to create checkout session: ' . esc_html($e->getMessage()));
        }
    }
    
    
    /**
     * Check subscription status
     * 
     * @return array Subscription status information
     */
    public function check_subscription_status() {
        try {
            $response = $this->api_client->get_subscription_status();
            return $response;
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Failed to check subscription status: ' . $e->getMessage());
            }
            
            // Fallback to local subscription data
            return $this->get_local_subscription_status();
        }
    }
    
    /**
     * Get local subscription status
     * 
     * @return array Local subscription status
     */
    public function get_local_subscription_status() {
        $subscription = get_option('alloia_subscription', array());
        
        if (empty($subscription)) {
            return array(
                'status' => 'none',
                'plan' => null,
                'expires_at' => null,
                'is_active' => false
            );
        }
        
        $is_active = in_array($subscription['status'], array('active', 'trialing'));
        $expires_at = $subscription['current_period_end'] ?? null;
        
        // Determine plan from plan_id
        $plan = $this->get_plan_from_id($subscription['plan_id']);
        
        return array(
            'status' => $subscription['status'],
            'plan' => $plan,
            'expires_at' => $expires_at,
            'is_active' => $is_active,
            'stripe_subscription_id' => $subscription['stripe_subscription_id'] ?? null,
            'stripe_customer_id' => $subscription['stripe_customer_id'] ?? null
        );
    }
    
    /**
     * Check if user has active subscription
     * 
     * @return bool True if subscription is active
     */
    public function has_active_subscription() {
        $status = $this->get_local_subscription_status();
        return $status['is_active'];
    }
    
    /**
     * Check if user has specific plan
     * 
     * @param string $plan_name Plan name (dashboard, graph, enterprise)
     * @return bool True if user has the plan
     */
    public function has_plan($plan_name) {
        // Check if we have recent cached subscription data (within 15 minutes)
        $cached_subscription = get_transient('alloia_subscription_cache');
        if ($cached_subscription && isset($cached_subscription['cached_at'])) {
            $cache_age = time() - $cached_subscription['cached_at'];
            if ($cache_age < 900) { // 15 minutes
                if (isset($cached_subscription['plan_key']) && $cached_subscription['is_active']) {
                    return $cached_subscription['plan_key'] === $plan_name;
                } elseif (!$cached_subscription['is_active']) {
                    return false;
                }
            }
        }
        
        // Try to get status from API if we have an API client
        if ($this->api_client) {
            try {
                $api_status = $this->check_subscription_status();
                
                // Handle different possible API response formats
                $is_active = false;
                $plan_key = null;
                
                if (isset($api_status['is_active'])) {
                    $is_active = $api_status['is_active'];
                } elseif (isset($api_status['status'])) {
                    $is_active = in_array($api_status['status'], array('active', 'trialing'));
                }
                
                if ($is_active) {
                    // Try to determine plan from various possible fields in the API response
                    if (isset($api_status['plan']['key'])) {
                        $plan_key = $api_status['plan']['key'];
                    } elseif (isset($api_status['plan_key'])) {
                        $plan_key = $api_status['plan_key'];
                    } elseif (isset($api_status['plan_id'])) {
                        // Convert plan_id to plan_key
                        $plan_info = $this->get_plan_from_id($api_status['plan_id']);
                        $plan_key = $plan_info ? $plan_info['key'] : null;
                    } elseif (isset($api_status['subscription_plan'])) {
                        // Handle subscription_plan field (your API format)
                        $plan_key = $this->normalize_plan_name($api_status['subscription_plan']);
                    } elseif (isset($api_status['client']['subscription_tier'])) {
                        // Handle client.subscription_tier field from client validation
                        $plan_key = $this->normalize_plan_name($api_status['client']['subscription_tier']);
                    }
                    
                    if ($plan_key) {
                        // Cache successful API response for 15 minutes
                        set_transient('alloia_subscription_cache', array(
                            'is_active' => true,
                            'plan_key' => $plan_key,
                            'cached_at' => time(),
                            'source' => 'api'
                        ), 900);
                        
                        // Update local cache with API data
                        $this->update_local_subscription_cache($api_status);
                        return $plan_key === $plan_name;
                    }
                } else {
                    // Cache inactive status for 5 minutes (shorter cache for inactive)
                    set_transient('alloia_subscription_cache', array(
                        'is_active' => false,
                        'plan_key' => null,
                        'cached_at' => time(),
                        'source' => 'api'
                    ), 300);
                }
            } catch (Exception $e) {
                // Check if this is a rate limit error
                if (strpos($e->getMessage(), 'Rate limit exceeded') !== false) {
                    // For rate limit errors, use local cache or extend existing cache
                    $local_status = $this->get_local_subscription_status();
                    if ($local_status['is_active'] && $local_status['plan']) {
                        // Cache the local data temporarily during rate limiting
                        set_transient('alloia_subscription_cache', array(
                            'is_active' => true,
                            'plan_key' => $local_status['plan']['key'],
                            'cached_at' => time(),
                            'source' => 'local_during_rate_limit'
                        ), 1800); // 30 minutes during rate limiting
                        
                        return $local_status['plan']['key'] === $plan_name;
                    }
                }
                
                // Log other API errors
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('API subscription check failed, using local data: ' . $e->getMessage());
                }
            }
        }
        
        // Fallback to local subscription status
        $status = $this->get_local_subscription_status();
        
        if (!$status['is_active'] || !$status['plan']) {
            return false;
        }
        
        // Compare with plan key, not plan name
        return $status['plan']['key'] === $plan_name;
    }
    
    /**
     * Get plan information from Stripe price ID
     * 
     * @param string $plan_id Stripe price ID
     * @return array|null Plan information or null if not found
     */
    private function get_plan_from_id($plan_id) {
        $plans = $this->get_available_plans();
        
        foreach ($plans as $plan_key => $plan) {
            if ($plan['id'] === $plan_id) {
                return array_merge($plan, array('key' => $plan_key));
            }
        }
        
        return null;
    }
    
    /**
     * Update local subscription cache with API data
     * 
     * @param array $api_status API subscription status response
     */
    private function update_local_subscription_cache($api_status) {
        $cache_data = array(
            'status' => $api_status['status'] ?? 'unknown',
            'plan_id' => $api_status['plan_id'] ?? '',
            'current_period_end' => $api_status['expires_at'] ?? null,
            'stripe_subscription_id' => $api_status['stripe_subscription_id'] ?? null,
            'stripe_customer_id' => $api_status['stripe_customer_id'] ?? null,
            'updated_at' => current_time('mysql'),
            'cached_from_api' => true
        );
        
        update_option('alloia_subscription', $cache_data);
    }
    
    /**
     * Manually set subscription status (for testing/debugging)
     * 
     * @param string $plan_key Plan key (dashboard, graph, enterprise)
     * @param string $status Subscription status (active, trialing, etc.)
     */
    public function set_subscription_status($plan_key, $status = 'active') {
        $plans = $this->get_available_plans();
        $plan_id = isset($plans[$plan_key]) ? $plans[$plan_key]['id'] : '';
        
        $subscription_data = array(
            'status' => $status,
            'plan_id' => $plan_id,
            'current_period_end' => wp_date('Y-m-d H:i:s', strtotime('+1 month')),
            'stripe_subscription_id' => 'manual_' . uniqid(),
            'stripe_customer_id' => 'manual_' . uniqid(),
            'updated_at' => current_time('mysql'),
            'manually_set' => true
        );
        
        update_option('alloia_subscription', $subscription_data);
        
        // Also set the transient cache
        set_transient('alloia_subscription_cache', array(
            'is_active' => in_array($status, array('active', 'trialing')),
            'plan_key' => $plan_key,
            'cached_at' => time(),
            'source' => 'manual'
        ), 3600); // 1 hour
    }
    
    /**
     * Clear subscription cache (for testing/debugging)
     */
    public function clear_subscription_cache() {
        delete_option('alloia_subscription');
        delete_transient('alloia_subscription_cache');
    }
    
    /**
     * Validate customer data
     * 
     * @param array $customer_data Customer data to validate
     * @throws Exception If validation fails
     */
    private function validate_customer_data($customer_data) {
        if (empty($customer_data['email']) || !is_email($customer_data['email'])) {
            throw new Exception('Valid email address is required');
        }
        
        if (empty($customer_data['plan_id'])) {
            throw new Exception('Plan ID is required');
        }
    }
    
    /**
     * Send trial ending notification
     * 
     * @param array $subscription Subscription data
     */
    private function send_trial_ending_notification($subscription) {
        // Log trial ending notification
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Trial ending notification for subscription: ' . $subscription['stripe_subscription_id']);
        }
    }
    
    /**
     * Cancel subscription
     * 
     * @return bool Success status
     */
    public function cancel_subscription() {
        $subscription = get_option('alloia_subscription', array());
        
        if (empty($subscription) || empty($subscription['stripe_subscription_id'])) {
            return false;
        }
        
        try {
            // Update local subscription status to canceled
            $subscription['status'] = 'canceled';
            $subscription['canceled_at'] = current_time('mysql');
            $subscription['updated_at'] = current_time('mysql');
            
            update_option('alloia_subscription', $subscription);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Subscription canceled locally: ' . $subscription['stripe_subscription_id']);
            }
            
            return true;
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Failed to cancel subscription: ' . $e->getMessage());
            }
            return false;
        }
    }
    
    /**
     * Get subscription usage information
     * 
     * @return array Usage information
     */
    public function get_usage_info() {
        $subscription = get_option('alloia_subscription', array());
        
        if (empty($subscription)) {
            return array(
                'api_calls_used' => 0,
                'api_calls_limit' => 'Unlimited',
                'products_exported' => 0,
                'products_limit' => 'Unlimited'
            );
        }
        
        // Get plan_id safely
        $plan_id = $subscription['plan_id'] ?? null;
        
        // This would typically come from the API
        // For now, return basic structure
        return array(
            'api_calls_used' => get_option('alloia_api_calls_used', 0),
            'api_calls_limit' => $plan_id ? $this->get_api_calls_limit($plan_id) : 'Unlimited',
            'products_exported' => get_option('alloia_products_exported', 0),
            'products_limit' => $plan_id ? $this->get_products_limit($plan_id) : 'Unlimited'
        );
    }
    
    /**
     * Get API calls limit for plan
     * 
     * @param string $plan_id Stripe price ID
     * @return int API calls limit
     */
    private function get_api_calls_limit($plan_id) {
        $plan = $this->get_plan_from_id($plan_id);
        
        if (!$plan) {
            return 1000; // Default limit
        }
        
        switch ($plan['key']) {
            case 'dashboard':
                return 5000;
            case 'graph':
                return 25000;
            case 'enterprise':
                return 100000;
            default:
                return 1000;
        }
    }
    
    /**
     * Get products limit for plan
     * 
     * @param string $plan_id Stripe price ID
     * @return int Products limit
     */
    private function get_products_limit($plan_id) {
        $plan = $this->get_plan_from_id($plan_id);
        
        if (!$plan) {
            return 100; // Default limit
        }
        
        switch ($plan['key']) {
            case 'dashboard':
                return 500;
            case 'graph':
                return 5000;
            case 'enterprise':
                return 50000;
            default:
                return 100;
        }
    }
    
    /**
     * Normalize plan name from API response to internal plan key
     * 
     * @param string $api_plan_name Plan name from API
     * @return string|null Normalized plan key
     */
    private function normalize_plan_name($api_plan_name) {
        if (empty($api_plan_name)) {
            return null;
        }
        
        // Handle various enterprise plan formats
        if (stripos($api_plan_name, 'enterprise') !== false) {
            return 'enterprise';
        }
        
        // Handle various graph plan formats
        if (stripos($api_plan_name, 'graph') !== false) {
            return 'graph';
        }
        
        // Handle various dashboard plan formats
        if (stripos($api_plan_name, 'dashboard') !== false) {
            return 'dashboard';
        }
        
        // Direct mapping for exact matches
        $plan_mappings = array(
            'enterprise_all_plans' => 'enterprise',
            'graph_plan' => 'graph',
            'dashboard_plan' => 'dashboard',
            'graph_1k' => 'graph',
            'graph_5k' => 'graph',
            'graph_10k' => 'graph'
        );
        
        return $plan_mappings[$api_plan_name] ?? strtolower($api_plan_name);
    }
}
